import logging
import boto3
import cv2
import numpy as np

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')
dynamo_db = boto3.client('dynamodb')
TABLE_NAME = 'tag-store-db'

def lambda_handler(event, context):
    # retrieve bucket name and file_key from the S3 event
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    file_key = event['Records'][0]['s3']['object']['key']
    logger.info('Reading {} from {}'.format(file_key, bucket_name))
    # get the object
    uploaded_image = s3.get_object(Bucket=bucket_name, Key=file_key)
    print('FILE KEY:'+file_key)
    
    #coco_names = s3.get_object(Bucket=bucket_name, Key='coco.names')
    #yolo_config = s3.get_object(Bucket=bucket_name, Key='yolov3.cfg')
    #yolo_weights = s3.get_object(Bucket=bucket_name, Key='yolov3.weights')
    
    # Downloading the yolov3.weights file and storing it in the /tmp folder
    strBucket = 'image-tag-bucket'
    strKey = 'yolov3.weights'
    strWeightFile = '/tmp/yolov3.weights'
    downloadFromS3(strBucket,strKey,strWeightFile) 

    # Downloading the yolov3.cfg file and storing it in the /tmp folder
    strKey = 'yolov3.cfg'
    strConfigFile = '/tmp/yolov3.cfg'
    downloadFromS3(strBucket,strKey,strConfigFile) 

    # Downloading the coco.names file from S3 and storing it in the /tmp folder
    strKey = 'coco.names'
    strNamesFile = '/tmp/coco.names'
    downloadFromS3(strBucket,strKey,strNamesFile)

    strBucket = 'image-tag-bucket'
    strKey = file_key
    strWeightFile = '/tmp/inputimage.jpg'
    downloadFromS3(strBucket,strKey,strWeightFile) 

    item = {}

    item['id'] = {'S': strKey}
    item['url'] = {'S': 'https://image-tag-bucket.s3.amazonaws.com/'+strKey}
    # Storing the JSON object in the item variable
    item['data'] = {'S': str(object_detect('/tmp/inputimage.jpg')) }
    print(item)
    
    # Strong the json object in the dynamo DB
    response = dynamo_db.put_item(TableName=TABLE_NAME, Item=item)

    print(response)
    
   
    
class DetectedObject:
    def __init__(self, label, accuracy):
        self.label = label
        self.accuracy = accuracy

class FinalResultObject:
    def __init__(self,objects):
        self.objects = objects


def object_detect(filename):
    net = cv2.dnn.readNet("/tmp/yolov3.weights", "/tmp/yolov3.cfg")
    classes = []
    with open("/tmp/coco.names", "r") as f:
        classes = [line.strip() for line in f.readlines()]
    layer_names = net.getLayerNames()
    output_layers = [layer_names[i[0]-1] for i in net.getUnconnectedOutLayers()]
    img = cv2.imread(filename)
    img = cv2.resize(img, None, fx=0.4, fy=0.4)
    blob = cv2.dnn.blobFromImage(img, scalefactor=0.00392, size=(320, 320), mean=(0, 0, 0), swapRB=True, crop=False)
    net.setInput(blob)
    outs = net.forward(output_layers)
    result_list = []
    for out in outs:
        for detection in out:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.5:
                 result_list.append(DetectedObject(classes[class_id], float(confidence)).__dict__)
    return FinalResultObject(result_list).__dict__

def downloadFromS3(strBucket,strKey,strFile):
    s3_client = boto3.client('s3')
    s3_client.download_file(strBucket, strKey, strFile)