#ifndef Py_ARRAYOBJECT_H
#define Py_ARRAYOBJECT_H

#include "ndarrayobject.h"
#include "npy_interrupt.h"

#ifdef NPY_NO_PREFIX
#include "noprefix.h"
#endif

#endif
